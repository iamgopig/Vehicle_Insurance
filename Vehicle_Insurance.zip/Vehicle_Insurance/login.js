document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const defaultUsers = [
        { id: 'user123', password: 'password123' },
        { id: 'admin456', password: 'adminpassword' },
        { id: 'guest789', password: 'guestpassword' }
    ];

    const enteredId = document.getElementById('login-id').value;
    const enteredPassword = document.getElementById('login-password').value;

    const user = defaultUsers.find(user => user.id === enteredId && user.password === enteredPassword);

    if (user) {
        window.location.href = 'home.html';
    } else {
        alert('Invalid ID or Password');
    }
});
