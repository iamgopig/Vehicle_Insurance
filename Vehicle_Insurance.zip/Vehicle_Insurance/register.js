document.getElementById('register-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const id = document.getElementById('register-id').value;
    const name = document.getElementById('register-name').value;
    const dob = document.getElementById('register-dob').value;
    const joiningDate = document.getElementById('register-joining-date').value;
    const password = document.getElementById('register-password').value;

    if (id && name && dob && joiningDate && password) {
        // In a real application, you would send this data to the server
        // For this example, we'll just log the details and redirect to home page
        console.log({
            id,
            name,
            dob,
            joiningDate,
            password
        });
        window.location.href = 'home.html';
    } else {
        alert('Please fill in all required fields');
    }
});
